import SwiftUI

enum Route: Hashable {
    case manga(String)
    case volume(mangaId: String, volume: Int)
    case discover
    case statistics
    case achievements
    case quests
    case wrapped
    case profile
    case publicProfile(String)
}

extension View {
    func vaultDestinations() -> some View {
        navigationDestination(for: Route.self) { route in
            switch route {
            case .manga(let id): MangaDetailView(mangaId: id)
            case .volume(let id, let vol): VolumeDetailView(mangaId: id, volume: vol)
            case .discover: CatalogView(mode: .discover)
            case .statistics: StatisticsView()
            case .achievements: AchievementsView()
            case .quests: QuestsView()
            case .wrapped: WrappedView()
            case .profile: ProfileView(profileId: nil)
            case .publicProfile(let id): ProfileView(profileId: id)
            }
        }
    }
}

enum MainTab: Hashable { case dashboard, catalog, collection, wishlist, more }

struct MainTabView: View {
    @Environment(AppState.self) private var app
    @State private var tab: MainTab = .dashboard
    @State private var morePath = NavigationPath()

    var body: some View {
        TabView(selection: $tab) {
            NavigationStack { DashboardView().vaultDestinations() }
                .tabItem { Label("Dashboard", systemImage: "square.grid.2x2.fill") }
                .tag(MainTab.dashboard)

            NavigationStack { CatalogView(mode: .catalog).vaultDestinations() }
                .tabItem { Label("Catalog", systemImage: "book.fill") }
                .tag(MainTab.catalog)

            NavigationStack { CollectionView().vaultDestinations() }
                .tabItem { Label("Collection", systemImage: "books.vertical.fill") }
                .tag(MainTab.collection)

            NavigationStack { WishlistView().vaultDestinations() }
                .tabItem { Label("Wishlist", systemImage: "heart.fill") }
                .tag(MainTab.wishlist)

            NavigationStack(path: $morePath) { MoreView().vaultDestinations() }
                .tabItem { Label("More", systemImage: "ellipsis.circle.fill") }
                .tag(MainTab.more)
        }
        .onChange(of: app.pendingProfileId, initial: true) { _, id in
            guard let id else { return }
            tab = .more
            morePath.append(Route.publicProfile(id))
            app.pendingProfileId = nil
        }
    }
}

struct MoreView: View {
    @Environment(AppState.self) private var app
    @State private var confirmLogout = false

    var body: some View {
        List {
            Section {
                NavigationLink(value: Route.profile) {
                    HStack(spacing: 12) {
                        LogoMark(size: 40)
                        VStack(alignment: .leading, spacing: 2) {
                            Text(app.displayName).font(.headline)
                            Text(app.user?.email ?? "").font(.caption).foregroundStyle(Theme.muted)
                        }
                    }
                    .padding(.vertical, 4)
                }
            }
            Section("Explore") {
                row("Discover", "safari.fill", .discover)
                row("Statistics", "chart.bar.xaxis", .statistics)
            }
            Section("Progress") {
                row("Achievements", "trophy.fill", .achievements)
                row("Daily Quests", "target", .quests)
                row("Manga Wrapped", "sparkles", .wrapped)
            }
            Section {
                Link(destination: Config.appBaseURL) {
                    Label("Open web version", systemImage: "globe")
                }
                Button(role: .destructive) { confirmLogout = true } label: {
                    Label("Log out", systemImage: "rectangle.portrait.and.arrow.right")
                }
            } footer: {
                Text("Manga Vault \(Bundle.main.appVersion) · data synced with mangas.base44.app")
            }
        }
        .scrollContentBackground(.hidden)
        .background(Theme.background)
        .navigationTitle("More")
        .confirmationDialog("Log out of Manga Vault?", isPresented: $confirmLogout, titleVisibility: .visible) {
            Button("Log out", role: .destructive) { app.signOut() }
        }
    }

    private func row(_ title: String, _ icon: String, _ route: Route) -> some View {
        NavigationLink(value: route) {
            Label { Text(title) } icon: { Image(systemName: icon).foregroundStyle(Theme.primary) }
        }
    }
}

extension Bundle {
    var appVersion: String {
        let v = infoDictionary?["CFBundleShortVersionString"] as? String ?? "1.0.0"
        let b = infoDictionary?["CFBundleVersion"] as? String ?? "1"
        return "\(v) (\(b))"
    }
}
