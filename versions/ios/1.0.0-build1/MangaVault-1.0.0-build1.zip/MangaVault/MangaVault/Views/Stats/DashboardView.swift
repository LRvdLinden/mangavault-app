import SwiftUI
import Charts

struct ChartDatum: Identifiable, Hashable {
    let name: String
    let value: Int
    var key: String = ""
    var id: String { name }
}

enum ChartData {
    static func status(_ items: [CollectionItem]) -> [ChartDatum] {
        [ChartDatum(name: "Reading", value: items.filter { $0.effectiveStatus == .reading }.count, key: "reading"),
         ChartDatum(name: "Completed", value: items.filter { $0.effectiveStatus == .completed }.count, key: "completed"),
         ChartDatum(name: "Plan", value: items.filter { $0.effectiveStatus == .plan_to_read }.count, key: "plan_to_read"),
         ChartDatum(name: "On Hold", value: items.filter { $0.effectiveStatus == .on_hold }.count, key: "on_hold")]
    }

    /// Cumulative volumes per month (yyyy-MM).
    static func growth(_ items: [CollectionItem]) -> [ChartDatum] {
        var perMonth: [String: Int] = [:]
        for i in items { let m = String((i.created_date ?? "").prefix(7)); if !m.isEmpty { perMonth[m, default: 0] += 1 } }
        var total = 0
        return perMonth.keys.sorted().map { k in total += perMonth[k]!; return ChartDatum(name: k, value: total) }
    }

    static func ratings(_ items: [CollectionItem]) -> [ChartDatum] {
        var b = [0, 0, 0, 0, 0]
        for i in items {
            let r = i.ratingValue
            if r >= 1 && r <= 2 { b[0] += 1 } else if r >= 3 && r <= 4 { b[1] += 1 }
            else if r >= 5 && r <= 6 { b[2] += 1 } else if r >= 7 && r <= 8 { b[3] += 1 } else if r >= 9 && r <= 10 { b[4] += 1 }
        }
        return zip(["1-2", "3-4", "5-6", "7-8", "9-10"], b).map { ChartDatum(name: $0, value: $1) }
    }

    static func color(forStatusKey k: String) -> Color {
        Theme.statusColor(ReadStatus(rawValue: k) ?? .reading)
    }
}

struct DashboardView: View {
    @Environment(AppState.self) private var app
    @State private var items: [CollectionItem] = []
    @State private var genreMap: [String: String] = [:]
    @State private var profile: UserProfile?
    @State private var streak = 0
    @State private var totalXP = 0
    @State private var loading = true

    private var level: LevelInfo { XP.level(for: totalXP) }
    private var name: String { nonEmpty(profile?.display_name) ?? app.displayName }

    var body: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 22) {
                header
                if loading && items.isEmpty {
                    LazyVGrid(columns: [GridItem(.flexible()), GridItem(.flexible())], spacing: 10) {
                        ForEach(0..<8, id: \.self) { _ in RoundedRectangle(cornerRadius: 14).fill(Theme.card.opacity(0.5)).frame(height: 84) }
                    }
                } else {
                    levelCard
                    statGrid
                    charts
                    continueReading
                    recentlyAdded
                    HStack(spacing: 10) {
                        NavigationLink(value: Route.statistics) { Label("Full Statistics", systemImage: "chart.bar.xaxis").frame(maxWidth: .infinity) }
                            .buttonStyle(OutlineButtonStyle(color: Theme.primary, border: Theme.primary.opacity(0.4)))
                        NavigationLink(value: Route.quests) { Label("Daily Quests", systemImage: "target").frame(maxWidth: .infinity) }
                            .buttonStyle(PrimaryButtonStyle())
                    }
                }
            }
            .padding(16)
        }
        .background(Theme.background)
        .navigationTitle("Dashboard")
        .navigationBarTitleDisplayMode(.inline)
        .toolbar { ToolbarItem(placement: .principal) { Wordmark(size: 18) } }
        .refreshable { await load() }
        .task(id: app.dataVersion) { await load() }
    }

    private var header: some View {
        VStack(alignment: .leading, spacing: 4) {
            Label("DASHBOARD", systemImage: "sparkles").font(.caption.weight(.bold)).tracking(2).foregroundStyle(Theme.primary)
            (Text("Welcome back, ").foregroundStyle(Theme.primary) + Text(name).foregroundStyle(Theme.foreground))
                .font(.system(size: 30, weight: .black)).tracking(-1)
            Text("Level \(level.level) · \(totalXP) XP · \(streak)-day streak").font(.subheadline).foregroundStyle(Theme.muted)
        }
    }

    private var levelCard: some View {
        NavigationLink(value: Route.achievements) {
            HStack(spacing: 16) {
                VStack(spacing: 0) {
                    Text("LVL").font(.caption2.weight(.black)).foregroundStyle(Theme.muted)
                    Text("\(level.level)").font(.system(size: 34, weight: .black)).foregroundStyle(Theme.primary)
                }
                .frame(width: 64)
                VStack(alignment: .leading, spacing: 6) {
                    HStack {
                        Text("\(level.into) / \(level.span) XP to Level \(level.level + 1)").font(.caption.weight(.bold)).foregroundStyle(Theme.muted)
                        Spacer()
                        Image(systemName: "flame.fill").foregroundStyle(Theme.primary)
                        Text("\(streak)d").font(.caption.weight(.black))
                    }
                    ProgressBar(value: level.progress)
                }
                Image(systemName: "chevron.right").foregroundStyle(Theme.muted)
            }
            .padding(16)
            .cardStyle(highlighted: true)
        }
        .buttonStyle(.plain)
    }

    private var statGrid: some View {
        let count: (ReadStatus) -> Int = { s in items.filter { $0.effectiveStatus == s }.count }
        let rated = items.filter { ($0.rating ?? 0) > 0 }
        let avg = rated.isEmpty ? "—" : String(format: "%.1f", rated.reduce(0.0) { $0 + ($1.rating ?? 0) } / Double(rated.count))
        return LazyVGrid(columns: [GridItem(.flexible()), GridItem(.flexible())], spacing: 10) {
            StatCard(icon: "books.vertical", label: "Volumes", value: "\(items.count)")
            StatCard(icon: "book", label: "Reading", value: "\(count(.reading))")
            StatCard(icon: "checkmark.circle", label: "Completed", value: "\(count(.completed))", accent: Theme.emerald)
            StatCard(icon: "bookmark", label: "Plan to Read", value: "\(count(.plan_to_read))", accent: Theme.sky)
            StatCard(icon: "pause.circle", label: "On Hold", value: "\(count(.on_hold))", accent: Theme.orange)
            StatCard(icon: "heart", label: "Favorites", value: "\(items.filter { $0.isFavorite }.count)", accent: Theme.red)
            StatCard(icon: "eurosign.circle", label: "Total Value", value: items.reduce(0.0) { $0 + ($1.price ?? 0) }.euro)
            StatCard(icon: "star", label: "Avg Rating", value: avg, accent: Theme.orange)
        }
    }

    private var viewAll: AnyView {
        AnyView(NavigationLink(value: Route.statistics) { Text("View all").font(.caption.weight(.bold)).foregroundStyle(Theme.primary) })
    }

    @ViewBuilder private var charts: some View {
        let status = ChartData.status(items).filter { $0.value > 0 }
        let genres = VaultService.genreDistribution(items, genreMap, top: 8).map { ChartDatum(name: $0.0, value: $0.1) }

        SectionCard(title: "Status Distribution", trailing: viewAll) {
            if status.isEmpty { emptyChart } else {
                Chart(status) { d in
                    SectorMark(angle: .value("Count", d.value), innerRadius: .ratio(0.55), angularInset: 2)
                        .foregroundStyle(ChartData.color(forStatusKey: d.key))
                        .cornerRadius(3)
                }
                .frame(height: 190)
                FlowLayout(spacing: 12) {
                    ForEach(status) { d in
                        HStack(spacing: 5) {
                            Circle().fill(ChartData.color(forStatusKey: d.key)).frame(width: 9, height: 9)
                            Text("\(d.name) \(d.value)").font(.caption.weight(.bold)).foregroundStyle(Theme.muted)
                        }
                    }
                }
            }
        }
        SectionCard(title: "Top Genres", trailing: viewAll) {
            if genres.isEmpty { emptyChart } else { GenreBarChart(data: genres) }
        }
        SectionCard(title: "Collection Growth", trailing: viewAll) {
            let g = ChartData.growth(items)
            if g.isEmpty { emptyChart } else { GrowthChart(data: g) }
        }
        SectionCard(title: "Rating Distribution", trailing: viewAll) {
            Chart(ChartData.ratings(items)) { d in
                BarMark(x: .value("Rating", d.name), y: .value("Count", d.value))
                    .foregroundStyle(Theme.primary).cornerRadius(4)
            }
            .chartYAxis { AxisMarks { _ in AxisGridLine().foregroundStyle(Theme.border); AxisValueLabel().foregroundStyle(Theme.muted) } }
            .chartXAxis { AxisMarks { _ in AxisValueLabel().foregroundStyle(Theme.muted) } }
            .frame(height: 180)
        }
    }

    private var emptyChart: some View {
        Text("No data yet.").font(.subheadline).foregroundStyle(Theme.muted).frame(maxWidth: .infinity, minHeight: 120)
    }

    private var continueReading: some View {
        let reading = items.filter { $0.effectiveStatus == .reading }
            .sorted { ($0.last_read_date ?? "") > ($1.last_read_date ?? "") }
            .prefix(6)
        return VStack(alignment: .leading, spacing: 12) {
            Label("CONTINUE READING", systemImage: "flame.fill").font(.title3.weight(.black)).labelStyle(TintedIconLabelStyle())
            if reading.isEmpty {
                Text("You're not reading anything right now. Set a volume's status to \"Reading\" from your collection.")
                    .font(.subheadline).foregroundStyle(Theme.muted).frame(maxWidth: .infinity).padding(24).cardStyle()
            } else {
                shelf(Array(reading), showProgress: true)
            }
        }
    }

    private var recentlyAdded: some View {
        VStack(alignment: .leading, spacing: 12) {
            Label("RECENTLY ADDED", systemImage: "sparkles").font(.title3.weight(.black)).labelStyle(TintedIconLabelStyle())
            if items.isEmpty {
                Text("Your collection is empty.").font(.subheadline).foregroundStyle(Theme.muted).frame(maxWidth: .infinity).padding(24).cardStyle()
            } else {
                shelf(Array(items.prefix(6)), showProgress: false)
            }
        }
    }

    private func shelf(_ list: [CollectionItem], showProgress: Bool) -> some View {
        ScrollView(.horizontal, showsIndicators: false) {
            HStack(alignment: .top, spacing: 12) {
                ForEach(list) { i in
                    NavigationLink(value: Route.manga(i.manga_id ?? "")) {
                        VStack(alignment: .leading, spacing: 4) {
                            CoverView(info: CoverInfo(item: i))
                            Text(i.titleText).font(.caption.weight(.bold)).lineLimit(1)
                            if showProgress {
                                Text("Vol. \(i.volume.map(String.init) ?? "—")\(i.chapter > 0 ? " · Ch.\(i.chapter)" : "")")
                                    .font(.caption2.weight(.bold)).foregroundStyle(Theme.primary)
                            }
                        }
                        .frame(width: 110)
                    }
                    .buttonStyle(.plain)
                }
            }
        }
    }

    private func load() async {
        loading = true
        defer { loading = false }
        do {
            async let itemsT = VaultService.collection()
            async let actsT = VaultService.activities()
            let its = try await itemsT
            let acts = try await actsT
            let gm = try await VaultService.genreMap(for: its)
            items = its; genreMap = gm
            streak = VaultService.streak(acts)
            if let uid = app.user?.id { profile = await ProfileStore.shared.current(userId: uid) }
            let genres = VaultService.genreCount(its, gm)
            totalXP = XP.base(items: its, genres: genres) + (profile?.xpBonus ?? 0)
            await unlockAchievements(its, acts, genres)
        } catch {
            if !(error is CancellationError) { app.fail("Could not load dashboard", error) }
        }
    }

    /// Credits newly reached achievements right away (the web app does this on its Achievements page).
    private func unlockAchievements(_ its: [CollectionItem], _ acts: [ReadingActivity], _ genres: Int) async {
        guard let uid = app.user?.id,
              let r = try? await AchievementEngine.run(userId: uid, items: its, activities: acts, genres: genres),
              !r.newlyUnlocked.isEmpty else { return }
        profile = r.profile
        totalXP = r.totalXP
        app.celebrate()
        let names = r.newlyUnlocked.map(\.name).joined(separator: ", ")
        app.show("Achievement unlocked: \(names)", "+\(r.newlyUnlocked.reduce(0) { $0 + $1.reward }) XP")
    }
}

struct GenreBarChart: View {
    let data: [ChartDatum]
    var body: some View {
        Chart(data) { d in
            BarMark(x: .value("Count", d.value), y: .value("Genre", d.name.capitalized))
                .foregroundStyle(Theme.primary).cornerRadius(4)
        }
        .chartXAxis(.hidden)
        .chartYAxis { AxisMarks { _ in AxisValueLabel().foregroundStyle(Theme.muted) } }
        .frame(height: CGFloat(max(120, data.count * 30)))
    }
}

struct GrowthChart: View {
    let data: [ChartDatum]
    var body: some View {
        Chart(data) { d in
            AreaMark(x: .value("Month", d.name), y: .value("Total", d.value))
                .foregroundStyle(LinearGradient(colors: [Theme.primary.opacity(0.5), Theme.primary.opacity(0)], startPoint: .top, endPoint: .bottom))
                .interpolationMethod(.monotone)
            LineMark(x: .value("Month", d.name), y: .value("Total", d.value))
                .foregroundStyle(Theme.primary).lineStyle(StrokeStyle(lineWidth: 2))
                .interpolationMethod(.monotone)
        }
        .chartYAxis { AxisMarks { _ in AxisGridLine().foregroundStyle(Theme.border); AxisValueLabel().foregroundStyle(Theme.muted) } }
        .chartXAxis { AxisMarks { _ in AxisValueLabel().foregroundStyle(Theme.muted) } }
        .frame(height: 190)
    }
}
