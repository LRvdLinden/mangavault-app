import SwiftUI

struct AchievementsView: View {
    @Environment(AppState.self) private var app
    @State private var result: AchievementEngine.Result?
    @State private var loading = true

    var body: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 18) {
                ScreenHeader(eyebrow: "Achievements", eyebrowIcon: "trophy.fill", lead: "ACHIEVEMENTS &", accent: "XP")
                if loading && result == nil {
                    LoadingView()
                } else if let r = result {
                    levelCard(r)
                    LazyVGrid(columns: [GridItem(.adaptive(minimum: 300), spacing: 12)], spacing: 12) {
                        ForEach(r.evals) { e in card(e, date: r.unlockedDates[e.id]) }
                    }
                }
            }
            .padding(16)
        }
        .background(Theme.background)
        .navigationTitle("Achievements")
        .navigationBarTitleDisplayMode(.inline)
        .refreshable { await load() }
        .task { await load() }
    }

    private func levelCard(_ r: AchievementEngine.Result) -> some View {
        let l = r.level
        return VStack(alignment: .leading, spacing: 14) {
            HStack(alignment: .bottom) {
                VStack(alignment: .leading) {
                    Text("LEVEL").font(.caption.weight(.bold)).tracking(2).foregroundStyle(Theme.muted)
                    Text("\(l.level)").font(.system(size: 52, weight: .black)).foregroundStyle(Theme.primary)
                }
                Spacer()
                VStack(alignment: .trailing) {
                    Text("TOTAL XP").font(.caption.weight(.bold)).tracking(2).foregroundStyle(Theme.muted)
                    Text(r.totalXP.formatted()).font(.title.weight(.black))
                }
            }
            HStack {
                Text("\(l.into) / \(l.next) XP to Level \(l.level + 1)")
                Spacer()
                Text("\(l.percent)%")
            }
            .font(.caption.weight(.bold)).foregroundStyle(Theme.muted)
            ProgressBar(value: l.progress, height: 12)
        }
        .padding(20)
        .cardStyle()
    }

    private func card(_ e: AchievementEval, date: String?) -> some View {
        VStack(alignment: .leading, spacing: 12) {
            HStack(alignment: .top, spacing: 12) {
                Text(e.def.icon)
                    .font(.system(size: 26))
                    .frame(width: 50, height: 50)
                    .background(e.unlocked ? Theme.primary.opacity(0.15) : Theme.secondary, in: RoundedRectangle(cornerRadius: 10))
                    .grayscale(e.unlocked ? 0 : 1)
                    .opacity(e.unlocked ? 1 : 0.6)
                VStack(alignment: .leading, spacing: 3) {
                    HStack(spacing: 6) {
                        Text(e.def.name).font(.headline.weight(.black)).lineLimit(1)
                        Image(systemName: e.unlocked ? "checkmark.circle.fill" : "lock.fill")
                            .font(.caption).foregroundStyle(e.unlocked ? Theme.primary : Theme.muted)
                    }
                    Text(e.def.desc).font(.caption).foregroundStyle(Theme.muted).lineLimit(2)
                }
            }
            HStack {
                rarityBadge(e.def.rarity)
                Spacer()
                Label("+\(e.def.reward) XP", systemImage: "star.fill").font(.caption.weight(.bold)).foregroundStyle(Theme.primary)
            }
            if !e.unlocked {
                VStack(spacing: 4) {
                    HStack { Text("\(e.value) / \(e.total)"); Spacer(); Text("\(e.percent)%") }
                        .font(.caption2.weight(.bold)).foregroundStyle(Theme.muted)
                    ProgressBar(value: Double(e.percent) / 100, height: 6)
                }
            } else if let date, !date.isEmpty {
                Text("Unlocked \(date)").font(.caption2).foregroundStyle(Theme.muted)
            }
        }
        .padding(16)
        .cardStyle(highlighted: e.unlocked)
    }

    private func rarityBadge(_ r: Rarity) -> some View {
        let c: Color
        switch r {
        case .common: c = Color(white: 0.8)
        case .rare: c = Theme.sky
        case .epic: c = Theme.primary
        case .legendary: c = Theme.orange
        }
        return Text(r.label).font(.system(size: 10, weight: .black))
            .padding(.horizontal, 8).padding(.vertical, 3)
            .foregroundStyle(c)
            .background(c.opacity(0.15), in: RoundedRectangle(cornerRadius: 4))
            .overlay(RoundedRectangle(cornerRadius: 4).stroke(c.opacity(0.5)))
    }

    private func load() async {
        guard let uid = app.user?.id else { loading = false; return }
        do {
            let r = try await AchievementEngine.run(userId: uid)
            result = r
            if !r.newlyUnlocked.isEmpty {
                app.celebrate()
                for a in r.newlyUnlocked { app.show("Achievement unlocked: \(a.name)", "+\(a.reward) XP") }
            }
        } catch {
            if !(error is CancellationError) { app.fail("Could not load achievements", error) }
        }
        loading = false
    }
}

struct QuestsView: View {
    @Environment(AppState.self) private var app
    @State private var quests: [QuestState] = []
    @State private var claimed: [String] = []
    @State private var loading = true
    @State private var claiming: String?

    private var resetTime: String {
        let midnight = Calendar.current.startOfDay(for: Date().addingTimeInterval(86_400))
        return midnight.formatted(date: .omitted, time: .shortened)
    }

    var body: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 18) {
                ScreenHeader(eyebrow: "Daily Quests", eyebrowIcon: "target", lead: "DAILY", accent: "QUESTS")
                Label("Resets at \(resetTime) (local time).", systemImage: "clock").font(.subheadline).foregroundStyle(Theme.muted)
                if loading && quests.isEmpty {
                    LoadingView()
                } else {
                    LazyVGrid(columns: [GridItem(.adaptive(minimum: 300), spacing: 12)], spacing: 12) {
                        ForEach(quests) { q in card(q) }
                    }
                }
            }
            .padding(16)
        }
        .background(Theme.background)
        .navigationTitle("Daily Quests")
        .navigationBarTitleDisplayMode(.inline)
        .refreshable { await load() }
        .task(id: app.dataVersion) { await load() }
    }

    private func card(_ q: QuestState) -> some View {
        let isClaimed = claimed.contains(q.id)
        return VStack(alignment: .leading, spacing: 10) {
            HStack {
                Image(systemName: q.def.bonus ? "sparkles" : "target").foregroundStyle(Theme.primary)
                Text(q.def.name).font(.headline.weight(.black))
                Spacer()
                if isClaimed {
                    Badge(text: "Claimed", icon: "checkmark", fg: Theme.emerald, bg: Theme.emerald.opacity(0.2), ring: Theme.emerald.opacity(0.4))
                } else if q.def.bonus {
                    Badge(text: "BONUS", fg: Theme.primary, bg: Theme.primary.opacity(0.2), ring: Theme.primary.opacity(0.4))
                }
            }
            Text(q.def.desc).font(.subheadline).foregroundStyle(Theme.muted)
            HStack {
                Text("\(q.value) / \(q.def.total)")
                Spacer()
                Label("\(q.def.reward) XP", systemImage: "star.fill").foregroundStyle(Theme.primary)
            }
            .font(.caption.weight(.bold)).foregroundStyle(Theme.muted)
            ProgressBar(value: Double(q.percent) / 100)
            Button { Task { await claim(q) } } label: {
                Group {
                    if claiming == q.id { ProgressView().tint(.white) }
                    else { Text(isClaimed ? "Claimed" : (q.completed ? "Claim Reward" : "In Progress")) }
                }
                .frame(maxWidth: .infinity)
            }
            .buttonStyle(PrimaryButtonStyle())
            .opacity(!q.completed || isClaimed ? 0.5 : 1)
            .disabled(!q.completed || isClaimed || claiming != nil)
        }
        .padding(18)
        .background(q.def.bonus ? Theme.primary.opacity(0.05) : Theme.card.opacity(0.6), in: RoundedRectangle(cornerRadius: 14))
        .overlay(RoundedRectangle(cornerRadius: 14).stroke(q.def.bonus ? Theme.primary.opacity(0.4) : Theme.border))
    }

    private func load() async {
        guard let uid = app.user?.id else { loading = false; return }
        do {
            let today = DayKey.local()
            let acts = try await VaultService.activities(limit: 1000).filter { $0.day == today }
            var counts: [String: Int] = [:]
            acts.forEach { counts[$0.type ?? "", default: 0] += 1 }
            quests = QuestDef.all.map { QuestState(def: $0, value: min(counts[$0.key] ?? 0, $0.total)) }

            var p = try await ProfileStore.shared.ensure(userId: uid)
            if p.daily_date != today {
                try await Base44Client.shared.update("UserProfile", p.id, ["daily_date": today, "daily_claimed": [String]()])
                p.daily_date = today; p.daily_claimed = []
                await ProfileStore.shared.set(p)
            }
            claimed = p.daily_claimed ?? []
        } catch {
            if !(error is CancellationError) { app.fail("Could not load quests", error) }
        }
        loading = false
    }

    private func claim(_ q: QuestState) async {
        guard let uid = app.user?.id, claiming == nil else { return }
        claiming = q.id; defer { claiming = nil }
        do {
            var p = try await ProfileStore.shared.ensure(userId: uid)
            let newClaimed = (p.daily_claimed ?? []) + [q.id]
            let bonus = Double(p.xpBonus + q.def.reward)
            try await Base44Client.shared.update("UserProfile", p.id, ["daily_claimed": newClaimed, "xp_bonus": bonus])
            p.daily_claimed = newClaimed; p.xp_bonus = bonus
            await ProfileStore.shared.set(p)
            claimed = newClaimed
            app.celebrate()
            app.show("Quest complete: +\(q.def.reward) XP")
        } catch { app.fail("Could not claim", error) }
    }
}
