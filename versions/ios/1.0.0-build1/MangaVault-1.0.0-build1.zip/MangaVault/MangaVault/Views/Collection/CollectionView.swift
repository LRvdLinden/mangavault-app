import SwiftUI

/// Shared mutations on collection items, with the same activity logging as the web app.
@MainActor
enum CollectionActions {
    static func update(_ app: AppState, _ item: CollectionItem, _ data: [String: Any], toast: String?) async -> Bool {
        do {
            try await Base44Client.shared.update("CollectionItem", item.id, data)
            if let toast { app.show(toast) }
            app.dataChanged()
            return true
        } catch {
            app.fail("Update failed", error)
            return false
        }
    }

    static func setStatus(_ app: AppState, _ item: CollectionItem, _ s: ReadStatus) async -> Bool {
        let ok = await update(app, item, ["status": s.rawValue], toast: "Status updated")
        if ok {
            VaultService.log("status", mangaId: item.manga_id, title: item.title, volume: item.volume)
            if s == .completed { VaultService.log("completed", mangaId: item.manga_id, title: item.title, volume: item.volume) }
        }
        return ok
    }

    static func setRating(_ app: AppState, _ item: CollectionItem, _ r: Int) async -> Bool {
        let ok = await update(app, item, ["rating": r], toast: "Rating updated")
        if ok { VaultService.log("rated", mangaId: item.manga_id, title: item.title, volume: item.volume) }
        return ok
    }

    static func toggleFavorite(_ app: AppState, _ item: CollectionItem) async -> Bool {
        let ok = await update(app, item, ["favorite": !item.isFavorite],
                              toast: item.isFavorite ? "Removed from favorites" : "Added to favorites")
        if ok { VaultService.log("favorite", mangaId: item.manga_id, title: item.title, volume: item.volume) }
        return ok
    }

    static func setChapter(_ app: AppState, _ item: CollectionItem, _ ch: Int) async -> String? {
        let today = DayKey.local()
        let ok = await update(app, item, ["current_chapter": ch, "last_read_date": today], toast: "Progress updated")
        if ok { VaultService.log("progress", mangaId: item.manga_id, title: item.title, volume: item.volume, meta: "ch.\(ch)") }
        return ok ? today : nil
    }

    static func setNotes(_ app: AppState, _ item: CollectionItem, _ notes: String) async -> Bool {
        await update(app, item, ["notes": notes], toast: "Note saved")
    }

    static func remove(_ app: AppState, _ item: CollectionItem) async -> Bool {
        do {
            try await Base44Client.shared.delete("CollectionItem", item.id)
            app.show("Removed \"\(item.titleText)\"")
            app.dataChanged()
            return true
        } catch {
            app.fail("Remove failed", error)
            return false
        }
    }
}

struct CollectionView: View {
    @Environment(AppState.self) private var app
    @State private var items: [CollectionItem] = []
    @State private var loading = true
    @State private var search = ""
    @State private var statusFilter: ReadStatus?
    @State private var favoritesOnly = false
    @State private var sort = "recent"
    @State private var gridMode = true
    @State private var editing: CollectionItem?
    @State private var lastLoadedVersion = -1

    private var filtered: [CollectionItem] {
        let q = search.trimmingCharacters(in: .whitespaces).lowercased()
        var r = items.filter { q.isEmpty || $0.titleText.lowercased().contains(q) }
        if let statusFilter { r = r.filter { $0.effectiveStatus == statusFilter } }
        if favoritesOnly { r = r.filter { $0.isFavorite } }
        switch sort {
        case "title": r.sort { $0.titleText.localizedCompare($1.titleText) == .orderedAscending }
        case "rating": r.sort { ($0.rating ?? 0) > ($1.rating ?? 0) }
        default: r.sort { ($0.created_date ?? "") > ($1.created_date ?? "") }
        }
        return r
    }

    var body: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 18) {
                ScreenHeader(lead: "MY", accent: "COLLECTION", subtitle: "Your personal manga vault, volume by volume.")
                stats
                filters
                content
            }
            .padding(16)
        }
        .background(Theme.background)
        .navigationTitle("Collection")
        .navigationBarTitleDisplayMode(.inline)
        .searchable(text: $search, prompt: "Search your collection...")
        .toolbar {
            ToolbarItemGroup(placement: .topBarTrailing) {
                Menu {
                    Picker("Sort", selection: $sort) {
                        Text("Recently Added").tag("recent")
                        Text("Title A-Z").tag("title")
                        Text("Highest Rating").tag("rating")
                    }
                } label: { Image(systemName: "arrow.up.arrow.down") }
                Button { gridMode.toggle() } label: { Image(systemName: gridMode ? "list.bullet" : "square.grid.2x2") }
            }
        }
        .refreshable { await load() }
        .task(id: app.dataVersion) {
            // Reload when another screen changed data (but not after our own optimistic updates).
            if app.dataVersion != lastLoadedVersion { await load() }
        }
        .sheet(item: $editing) { it in
            CollectionItemEditor(item: it) { updated in
                if let i = items.firstIndex(where: { $0.id == updated.id }) { items[i] = updated }
            }
        }
    }

    private var stats: some View {
        let completed = items.filter { $0.effectiveStatus == .completed }.count
        let value = items.reduce(0.0) { $0 + ($1.price ?? 0) }
        let rated = items.filter { ($0.rating ?? 0) > 0 }
        let avg = rated.isEmpty ? "—" : String(format: "%.1f", rated.reduce(0.0) { $0 + ($1.rating ?? 0) } / Double(rated.count))
        return LazyVGrid(columns: [GridItem(.flexible()), GridItem(.flexible())], spacing: 10) {
            StatCard(icon: "books.vertical", label: "Volumes", value: "\(items.count)")
            StatCard(icon: "checkmark.circle", label: "Completed", value: "\(completed)", accent: Theme.emerald)
            StatCard(icon: "eurosign.circle", label: "Total Value", value: value.euro)
            StatCard(icon: "star", label: "Avg Rating", value: avg, accent: Theme.orange)
            StatCard(icon: "heart", label: "Favorites", value: "\(items.filter { $0.isFavorite }.count)", accent: Theme.red)
        }
    }

    private var filters: some View {
        ScrollView(.horizontal, showsIndicators: false) {
            HStack(spacing: 8) {
                Chip(title: "All", selected: statusFilter == nil) { statusFilter = nil }
                ForEach(ReadStatus.allCases) { s in
                    Chip(title: s.label, selected: statusFilter == s) { statusFilter = s }
                }
                Chip(title: "Favorites", icon: favoritesOnly ? "heart.fill" : "heart", selected: favoritesOnly, selectedColor: Theme.red) {
                    favoritesOnly.toggle()
                }
            }
        }
    }

    @ViewBuilder private var content: some View {
        if loading && items.isEmpty {
            LazyVGrid(columns: gridColumns, spacing: 16) {
                ForEach(0..<6, id: \.self) { _ in RoundedRectangle(cornerRadius: 10).fill(Theme.card.opacity(0.6)).aspectRatio(2/3, contentMode: .fit) }
            }
        } else if filtered.isEmpty {
            EmptyState(icon: "books.vertical",
                       text: items.isEmpty ? "Your collection is empty.\nOpen the Catalog to add the volumes you own." : "No volumes match your filters.")
        } else if gridMode {
            LazyVGrid(columns: gridColumns, spacing: 22) {
                ForEach(filtered) { item in gridCard(item) }
            }
        } else {
            LazyVStack(spacing: 10) {
                ForEach(filtered) { item in listRow(item) }
            }
        }
    }

    private func route(_ i: CollectionItem) -> Route {
        if i.isOmnibus || i.volume == nil { return .manga(i.manga_id ?? "") }
        return .volume(mangaId: i.manga_id ?? "", volume: i.volume!)
    }

    private func gridCard(_ item: CollectionItem) -> some View {
        let st = item.effectiveStatus
        return VStack(alignment: .leading, spacing: 6) {
            NavigationLink(value: route(item)) {
                CoverView(info: CoverInfo(item: item))
                    .overlay(alignment: .topTrailing) {
                        HStack(spacing: 3) {
                            Circle().fill(Theme.statusColor(st)).frame(width: 6, height: 6)
                            Text(st.label)
                        }
                        .font(.system(size: 9, weight: .black))
                        .padding(.horizontal, 6).padding(.vertical, 3)
                        .foregroundStyle(Theme.statusColor(st))
                        .background(.black.opacity(0.65), in: RoundedRectangle(cornerRadius: 4))
                        .padding(8)
                    }
                    .overlay(alignment: .bottomLeading) {
                        if item.chapter > 0 {
                            Text("Ch. \(item.chapter)").font(.system(size: 9, weight: .black)).foregroundStyle(Theme.primary)
                                .padding(.horizontal, 6).padding(.vertical, 3)
                                .background(Theme.background.opacity(0.85), in: RoundedRectangle(cornerRadius: 4))
                                .padding(8)
                        }
                    }
            }
            .buttonStyle(.plain)
            .overlay(alignment: .topLeading) {
                Button { Task { await toggleFavorite(item) } } label: {
                    Image(systemName: item.isFavorite ? "heart.fill" : "heart")
                        .font(.system(size: 12, weight: .bold))
                        .foregroundStyle(item.isFavorite ? Theme.red : Theme.muted)
                        .frame(width: 30, height: 30)
                        .background(.ultraThinMaterial, in: Circle())
                }
                .buttonStyle(.plain)
                .padding(6)
            }
            .contextMenu { itemMenu(item) }

            Text(item.titleText).font(.subheadline.weight(.bold)).lineLimit(1)
            HStack {
                Text(item.volumeLabel).font(.caption).foregroundStyle(Theme.muted)
                Spacer()
                Text((item.price ?? 0).euro).font(.caption.weight(.bold)).foregroundStyle(Theme.primary)
            }
            HStack {
                StarRating(value: item.ratingValue) { r in Task { await setRating(item, r) } }
                Spacer()
                statusMenu(item)
            }
            Button { editing = item } label: {
                Text("Details").frame(maxWidth: .infinity).font(.caption.weight(.bold))
            }
            .buttonStyle(OutlineButtonStyle(color: Theme.primary))
            .controlSize(.small)
        }
    }

    private func statusMenu(_ item: CollectionItem) -> some View {
        Menu {
            ForEach(ReadStatus.allCases) { s in
                Button { Task { await setStatus(item, s) } } label: {
                    if s == item.effectiveStatus { Label(s.label, systemImage: "checkmark") } else { Text(s.label) }
                }
            }
        } label: {
            Image(systemName: "ellipsis.circle").font(.system(size: 18)).foregroundStyle(Theme.muted)
        }
    }

    @ViewBuilder private func itemMenu(_ item: CollectionItem) -> some View {
        Menu("Status") {
            ForEach(ReadStatus.allCases) { s in
                Button(s.label) { Task { await setStatus(item, s) } }
            }
        }
        Button { editing = item } label: { Label("Rating, progress & notes", systemImage: "slider.horizontal.3") }
        Button { Task { await toggleFavorite(item) } } label: {
            Label(item.isFavorite ? "Remove favorite" : "Add favorite", systemImage: item.isFavorite ? "heart.slash" : "heart")
        }
        Button(role: .destructive) { Task { await remove(item) } } label: { Label("Remove", systemImage: "trash") }
    }

    private func listRow(_ item: CollectionItem) -> some View {
        let st = item.effectiveStatus
        return HStack(spacing: 12) {
            NavigationLink(value: route(item)) {
                CoverView(info: CoverInfo(item: item), cornerRadius: 6).frame(width: 52)
            }
            .buttonStyle(.plain)
            VStack(alignment: .leading, spacing: 4) {
                Text(item.titleText).font(.subheadline.weight(.bold)).lineLimit(1)
                Text("\(item.volumeLabel) · \((item.price ?? 0).euro)\(item.chapter > 0 ? " · Ch. \(item.chapter)" : "")")
                    .font(.caption).foregroundStyle(Theme.muted)
                HStack(spacing: 8) {
                    Text(st.label).font(.system(size: 10, weight: .black)).foregroundStyle(Theme.statusColor(st))
                        .padding(.horizontal, 6).padding(.vertical, 2)
                        .background(Theme.statusColor(st).opacity(0.18), in: RoundedRectangle(cornerRadius: 4))
                    StarRating(value: item.ratingValue, size: 11) { r in Task { await setRating(item, r) } }
                }
                if item.hasNotes {
                    Label(item.notes ?? "", systemImage: "note.text").font(.caption2).foregroundStyle(Theme.muted).lineLimit(1)
                }
            }
            Spacer(minLength: 0)
            VStack(spacing: 10) {
                Button { Task { await toggleFavorite(item) } } label: {
                    Image(systemName: item.isFavorite ? "heart.fill" : "heart").foregroundStyle(item.isFavorite ? Theme.red : Theme.muted)
                }
                .buttonStyle(.plain)
                statusMenu(item)
            }
        }
        .padding(12)
        .cardStyle()
        .contentShape(Rectangle())
        .onTapGesture { editing = item }
        .contextMenu { itemMenu(item) }
    }

    // MARK: Data

    private func load() async {
        loading = true
        do {
            items = try await VaultService.collection()
            lastLoadedVersion = app.dataVersion
        } catch {
            if !(error is CancellationError) { app.fail("Could not load collection", error) }
        }
        loading = false
    }

    private func patch(_ id: String, _ change: (inout CollectionItem) -> Void) {
        if let i = items.firstIndex(where: { $0.id == id }) { change(&items[i]) }
    }

    /// Mark our own change as seen so the dataVersion bump doesn't trigger a full reload.
    private func markSeen() { lastLoadedVersion = app.dataVersion + 1 }

    private func setStatus(_ item: CollectionItem, _ s: ReadStatus) async {
        patch(item.id) { $0.status = s.rawValue }
        markSeen()
        if !(await CollectionActions.setStatus(app, item, s)) { await load() }
    }

    private func setRating(_ item: CollectionItem, _ r: Int) async {
        patch(item.id) { $0.rating = Double(r) }
        markSeen()
        if !(await CollectionActions.setRating(app, item, r)) { await load() }
    }

    private func toggleFavorite(_ item: CollectionItem) async {
        patch(item.id) { $0.favorite = !item.isFavorite }
        markSeen()
        if !(await CollectionActions.toggleFavorite(app, item)) { await load() }
    }

    private func remove(_ item: CollectionItem) async {
        items.removeAll { $0.id == item.id }
        markSeen()
        if !(await CollectionActions.remove(app, item)) { await load() }
    }
}

// MARK: - Editor sheet (status, rating, favorite, chapter progress, notes)

struct CollectionItemEditor: View {
    @Environment(AppState.self) private var app
    @Environment(\.dismiss) private var dismiss
    @State var item: CollectionItem
    var onSave: (CollectionItem) -> Void

    @State private var chapterText = ""
    @State private var notes = ""
    @State private var saving = false
    @State private var confirmRemove = false

    init(item: CollectionItem, onSave: @escaping (CollectionItem) -> Void) {
        _item = State(initialValue: item)
        self.onSave = onSave
        _chapterText = State(initialValue: item.chapter > 0 ? String(item.chapter) : "")
        _notes = State(initialValue: item.notes ?? "")
    }

    var body: some View {
        NavigationStack {
            Form {
                Section {
                    HStack(spacing: 14) {
                        CoverView(info: CoverInfo(item: item), cornerRadius: 6).frame(width: 60)
                        VStack(alignment: .leading, spacing: 4) {
                            Text(item.titleText).font(.headline)
                            Text("\(item.volumeLabel) · \((item.price ?? 0).euro)").font(.caption).foregroundStyle(Theme.muted)
                        }
                    }
                }
                .listRowBackground(Theme.card)

                Section("Status") {
                    Picker("Status", selection: Binding(get: { item.effectiveStatus }, set: { s in
                        item.status = s.rawValue
                        let snapshot = item
                        Task { _ = await CollectionActions.setStatus(app, snapshot, s); onSave(snapshot) }
                    })) {
                        ForEach(ReadStatus.allCases) { Text($0.label).tag($0) }
                    }
                    .pickerStyle(.segmented)
                    Toggle(isOn: Binding(get: { item.isFavorite }, set: { v in
                        let before = item
                        item.favorite = v
                        let snapshot = item
                        Task { if await CollectionActions.toggleFavorite(app, before) { onSave(snapshot) } }
                    })) {
                        Label("Favorite", systemImage: "heart.fill").foregroundStyle(Theme.red)
                    }
                }
                .listRowBackground(Theme.card)

                Section("Rating") {
                    HStack {
                        StarRating(value: item.ratingValue, size: 26) { r in
                            item.rating = Double(r)
                            let snapshot = item
                            Task { if await CollectionActions.setRating(app, snapshot, r) { onSave(snapshot) } }
                        }
                        Spacer()
                        Text(item.ratingValue > 0 ? "\(item.ratingValue)/10" : "Not rated").font(.subheadline.weight(.bold)).foregroundStyle(Theme.muted)
                    }
                }
                .listRowBackground(Theme.card)

                Section {
                    HStack {
                        Text("Current chapter")
                        Spacer()
                        TextField("0", text: $chapterText)
                            .keyboardType(.numberPad)
                            .multilineTextAlignment(.trailing)
                            .frame(width: 90)
                    }
                    if let d = nonEmpty(item.last_read_date) {
                        Text("Updated \(d)").font(.caption).foregroundStyle(Theme.muted)
                    }
                } header: { Text("Reading progress") }
                .listRowBackground(Theme.card)

                Section("Notes") {
                    TextField("Add a note...", text: $notes, axis: .vertical).lineLimit(3...8)
                }
                .listRowBackground(Theme.card)

                Section {
                    Button(role: .destructive) { confirmRemove = true } label: {
                        Label("Remove from collection", systemImage: "trash")
                    }
                }
                .listRowBackground(Theme.card)
            }
            .scrollContentBackground(.hidden)
            .background(Theme.background)
            .navigationTitle("Details")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .cancellationAction) { Button("Close") { dismiss() } }
                ToolbarItem(placement: .confirmationAction) {
                    Button { Task { await saveText() } } label: {
                        if saving { ProgressView() } else { Text("Save").bold() }
                    }
                    .disabled(saving)
                }
            }
            .confirmationDialog("Remove \"\(item.titleText)\"?", isPresented: $confirmRemove, titleVisibility: .visible) {
                Button("Remove", role: .destructive) {
                    Task { if await CollectionActions.remove(app, item) { dismiss() } }
                }
            }
        }
        .presentationDetents([.large])
    }

    /// Saves chapter progress and notes (the fields the web app saves on blur).
    private func saveText() async {
        saving = true; defer { saving = false }
        let ch = Int(chapterText.trimmingCharacters(in: .whitespaces)) ?? 0
        if !chapterText.isEmpty, ch != item.chapter {
            if let day = await CollectionActions.setChapter(app, item, ch) {
                item.current_chapter = Double(ch)
                item.last_read_date = day
            }
        }
        if notes != (item.notes ?? "") {
            if await CollectionActions.setNotes(app, item, notes) { item.notes = notes }
        }
        onSave(item)
        dismiss()
    }
}
