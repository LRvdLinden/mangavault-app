import Foundation

// Field names mirror the Base44 entity schema exactly (snake_case), so the
// native app reads and writes the same records as the web app.

struct AppUser: Codable, Hashable {
    let id: String
    let email: String?
    let full_name: String?
}

struct VolumeCover: Codable, Hashable {
    let volume: Double
    let url: String?
}

struct Manga: Codable, Identifiable, Hashable {
    let id: String
    var title: String
    var publisher: String?
    var is_shonen_jump: Bool?
    var price: Double?
    var total_volumes: Double?
    var genre: String?
    var description: String?
    var languages: [String]?
    var cover_seed: String?
    var cover_image_url: String?
    var edition: String?
    var volumes_included: String?
    var omnibus_of: String?
    var mangadex_id: String?
    var volume_covers: [VolumeCover]?

    var isOmnibus: Bool { edition == "omnibus" }
    var isShonenJump: Bool { is_shonen_jump ?? false }
    var totalVolumes: Int { Int(total_volumes ?? 0) }
    var priceValue: Double { price ?? 0 }

    static let listFields = ["title", "cover_image_url", "cover_seed", "total_volumes", "price", "edition",
                             "volumes_included", "is_shonen_jump", "genre", "publisher", "omnibus_of"]
}

enum ReadStatus: String, CaseIterable, Identifiable {
    case reading, completed, plan_to_read, on_hold
    var id: String { rawValue }

    var label: String {
        switch self {
        case .reading: return "Reading"
        case .completed: return "Completed"
        case .plan_to_read: return "Plan to Read"
        case .on_hold: return "On Hold"
        }
    }
    /// Label used on the volume detail page of the web app.
    var volumeLabel: String { self == .plan_to_read ? "Want to Read" : label }
}

struct CollectionItem: Codable, Identifiable, Hashable {
    let id: String
    var manga_id: String?
    var title: String?
    var publisher: String?
    var price: Double?
    var total_volumes: Double?
    var is_shonen_jump: Bool?
    var cover_seed: String?
    var cover_image_url: String?
    var volume_number: Double?
    var volume_cover_url: String?
    var read: Bool?
    var edition: String?
    var volumes_included: String?
    var omnibus_of: String?
    var status: String?
    var rating: Double?
    var notes: String?
    var favorite: Bool?
    var current_chapter: Double?
    var last_read_date: String?
    var created_date: String?

    /// Same fallback as the web app: explicit status, else `read` → completed / plan_to_read.
    var effectiveStatus: ReadStatus {
        if let s = status, let st = ReadStatus(rawValue: s) { return st }
        return (read ?? false) ? .completed : .plan_to_read
    }
    var isOmnibus: Bool { edition == "omnibus" }
    var volume: Int? { volume_number.map { Int($0) } }
    var ratingValue: Int { Int(rating ?? 0) }
    var isFavorite: Bool { favorite ?? false }
    var chapter: Int { Int(current_chapter ?? 0) }
    var hasNotes: Bool { !(notes ?? "").trimmingCharacters(in: .whitespacesAndNewlines).isEmpty }
    var displayCover: String? { nonEmpty(volume_cover_url) ?? nonEmpty(cover_image_url) }
    var volumeLabel: String { isOmnibus ? (nonEmpty(volumes_included) ?? "Omnibus") : "Vol. \(volume.map(String.init) ?? "")" }
    var titleText: String { title ?? "" }
}

struct WishlistItem: Codable, Identifiable, Hashable {
    let id: String
    var manga_id: String?
    var title: String?
    var publisher: String?
    var price: Double?
    var is_shonen_jump: Bool?
    var cover_seed: String?
    var cover_image_url: String?
    var volume_number: Double?
    var volume_cover_url: String?
    var edition: String?
    var volumes_included: String?
    var omnibus_of: String?
    var created_date: String?

    var isOmnibus: Bool { edition == "omnibus" }
    var volume: Int? { volume_number.map { Int($0) } }
    var displayCover: String? { nonEmpty(volume_cover_url) ?? nonEmpty(cover_image_url) }
    var volumeLabel: String { isOmnibus ? (nonEmpty(volumes_included) ?? "Omnibus") : "Vol. \(volume.map(String.init) ?? "")" }
}

struct ReadingActivity: Codable, Identifiable, Hashable {
    let id: String
    var type: String?
    var manga_id: String?
    var title: String?
    var volume_number: Double?
    var meta: String?
    var created_date: String?

    var day: String { String((created_date ?? "").prefix(10)) }
}

struct UnlockedAchievement: Codable, Hashable {
    let id: String
    let date: String?
}

struct UserProfile: Codable, Identifiable, Hashable {
    let id: String
    var display_name: String?
    var bio: String?
    var avatar_url: String?
    var banner_url: String?
    var theme_id: String?
    var profile_public: Bool?
    var collection_public: Bool?
    var xp_bonus: Double?
    var unlocked_achievements: [UnlockedAchievement]?
    var featured_achievements: [String]?
    var daily_date: String?
    var daily_claimed: [String]?
    var created_by_id: String?

    var xpBonus: Int { Int(xp_bonus ?? 0) }
}

/// Response of the `getVolumeSynopsis` backend function.
struct VolumeSynopsis: Codable, Hashable {
    var synopsis: String?
    var recap: String?
    var location: String?
    var setting: String?
    var main_characters: [String]?
}

/// Decodes a JSON scalar (string or number) as a string — chapter numbers come back as either.
struct LooseString: Decodable, Hashable {
    let value: String
    init(from decoder: Decoder) throws {
        let c = try decoder.singleValueContainer()
        if let s = try? c.decode(String.self) { value = s }
        else if let i = try? c.decode(Int.self) { value = String(i) }
        else if let d = try? c.decode(Double.self) { value = d == d.rounded() ? String(Int(d)) : String(d) }
        else { value = "" }
    }
}

func nonEmpty(_ s: String?) -> String? {
    guard let s, !s.isEmpty else { return nil }
    return s
}

extension Double {
    var euro: String { String(format: "€%.2f", self) }
}
