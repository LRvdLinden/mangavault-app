import Foundation

// Faithful port of the XP / level / achievement / quest / streak rules of the web app.

struct LevelInfo: Hashable {
    let level: Int
    let into: Int
    let span: Int
    let next: Int
    let total: Int

    var progress: Double { span > 0 ? min(1, Double(into) / Double(span)) : 1 }
    var percent: Int { span > 0 ? Int((Double(into) / Double(span) * 100).rounded()) : 100 }
}

enum XP {
    static func threshold(_ level: Int) -> Int { 50 * level * (level - 1) }

    static func level(for xp: Int) -> LevelInfo {
        var l = 1
        while threshold(l + 1) <= xp { l += 1 }
        let start = threshold(l), end = threshold(l + 1)
        return LevelInfo(level: l, into: xp - start, span: end - start, next: end, total: xp)
    }

    /// volumes×10 + completed×30 + rated×15 + favorites×5 + notes×8 + genres×20
    static func base(items: [CollectionItem], genres: Int) -> Int {
        let n = items.count
        let completed = items.filter { $0.effectiveStatus == .completed }.count
        let rated = items.filter { ($0.rating ?? 0) > 0 }.count
        let favs = items.filter { $0.isFavorite }.count
        let notes = items.filter { $0.hasNotes }.count
        return n * 10 + completed * 30 + rated * 15 + favs * 5 + notes * 8 + max(0, genres) * 20
    }
}

enum Rarity: String {
    case common, rare, epic, legendary
    var label: String { rawValue.capitalized }
}

struct AchievementStats {
    var vol = 0, completed = 0, rated = 0, notes = 0, progressCount = 0, genres = 0, streak = 0

    init(items: [CollectionItem], genres: Int, streak: Int) {
        vol = items.count
        completed = items.filter { $0.effectiveStatus == .completed }.count
        rated = items.filter { ($0.rating ?? 0) > 0 }.count
        notes = items.filter { $0.hasNotes }.count
        progressCount = items.filter { ($0.current_chapter ?? 0) > 0 }.count
        self.genres = genres
        self.streak = streak
    }
}

struct AchievementDef: Identifiable {
    let id: String
    let name: String
    let desc: String
    let rarity: Rarity
    let reward: Int
    let icon: String
    let total: Int
    let value: (AchievementStats) -> Int

    static let all: [AchievementDef] = [
        .init(id: "first_add", name: "First Addition", desc: "Add your first manga to your collection", rarity: .common, reward: 50, icon: "+", total: 1, value: { $0.vol }),
        .init(id: "collector", name: "Collector", desc: "Collect 10 manga volumes", rarity: .common, reward: 100, icon: "📚", total: 10, value: { $0.vol }),
        .init(id: "dedicated", name: "Dedicated Collector", desc: "Collect 50 manga volumes", rarity: .rare, reward: 300, icon: "🗂", total: 50, value: { $0.vol }),
        .init(id: "expert", name: "Manga Expert", desc: "Collect 100 manga volumes", rarity: .epic, reward: 800, icon: "👑", total: 100, value: { $0.vol }),
        .init(id: "first_chapter", name: "First Chapter", desc: "Record reading progress on a volume", rarity: .common, reward: 50, icon: "📖", total: 1, value: { $0.progressCount }),
        .init(id: "getting_started", name: "Getting Started", desc: "Complete your first manga", rarity: .common, reward: 100, icon: "✓", total: 1, value: { $0.completed }),
        .init(id: "completionist", name: "Completionist", desc: "Complete 10 manga", rarity: .rare, reward: 400, icon: "🏆", total: 10, value: { $0.completed }),
        .init(id: "genre_explorer", name: "Genre Explorer", desc: "Collect manga from 5 different genres", rarity: .rare, reward: 200, icon: "🧭", total: 5, value: { $0.genres }),
        .init(id: "variety_fan", name: "Variety Fan", desc: "Explore 10 different genres", rarity: .epic, reward: 400, icon: "🎨", total: 10, value: { $0.genres }),
        .init(id: "rating_master", name: "Rating Master", desc: "Rate 25 manga", rarity: .rare, reward: 250, icon: "⭐", total: 25, value: { $0.rated }),
        .init(id: "organized", name: "Organized Reader", desc: "Add notes to 10 manga", rarity: .common, reward: 150, icon: "📝", total: 10, value: { $0.notes }),
        .init(id: "streak", name: "Consistent Reader", desc: "Maintain a 7-day reading streak", rarity: .epic, reward: 500, icon: "🔥", total: 7, value: { $0.streak })
    ]
}

struct AchievementEval: Identifiable {
    let def: AchievementDef
    let value: Int
    let unlocked: Bool
    var id: String { def.id }
    var total: Int { def.total }
    var percent: Int { total > 0 ? min(100, Int((Double(value) / Double(total) * 100).rounded())) : 0 }

    static func evaluate(_ stats: AchievementStats) -> [AchievementEval] {
        AchievementDef.all.map { def in
            let v = def.value(stats)
            return AchievementEval(def: def, value: min(v, def.total), unlocked: v >= def.total)
        }
    }
}

struct QuestDef: Identifiable, Hashable {
    let id: String
    let name: String
    let desc: String
    let reward: Int
    let bonus: Bool
    let key: String
    let total: Int

    static let all: [QuestDef] = [
        .init(id: "q_add", name: "Add a Manga", desc: "Add a manga to your collection today", reward: 30, bonus: false, key: "added", total: 1),
        .init(id: "q_rate", name: "Rate a Manga", desc: "Rate a manga in your collection today", reward: 30, bonus: false, key: "rated", total: 1),
        .init(id: "q_progress", name: "Update Progress", desc: "Update reading progress on a volume today", reward: 40, bonus: false, key: "progress", total: 1),
        .init(id: "q_complete", name: "Complete a Manga", desc: "Complete a manga today", reward: 80, bonus: true, key: "completed", total: 1)
    ]
}

struct QuestState: Identifiable, Hashable {
    let def: QuestDef
    let value: Int
    var id: String { def.id }
    var completed: Bool { value >= def.total }
    var percent: Int { def.total > 0 ? min(100, Int((Double(value) / Double(def.total) * 100).rounded())) : 0 }
}

enum DayKey {
    /// Local `yyyy-MM-dd`, like the web app's `S_()` helper.
    static func local(_ date: Date = Date()) -> String {
        let c = Calendar.current.dateComponents([.year, .month, .day], from: date)
        return String(format: "%04d-%02d-%02d", c.year ?? 0, c.month ?? 0, c.day ?? 0)
    }

    /// Consecutive-day streak ending today (or yesterday), based on activity days.
    static func streak(_ days: [String]) -> Int {
        let set = Set(days)
        var date = Date()
        let yesterday = date.addingTimeInterval(-86_400)
        if !set.contains(local(date)) && !set.contains(local(yesterday)) { return 0 }
        if !set.contains(local(date)) { date = yesterday }
        var n = 0
        while set.contains(local(date)) {
            n += 1
            date = date.addingTimeInterval(-86_400)
        }
        return n
    }
}
