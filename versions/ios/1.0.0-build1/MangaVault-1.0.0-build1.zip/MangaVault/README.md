# Manga Vault — iOS

Native SwiftUI app for **Manga Vault** (https://mangas.base44.app). It talks to the same Base44 backend as the web app, so your account, collection, wishlist, XP and achievements are shared between web and iPhone/iPad.

- Bundle ID: `nl.lrvdlinden.mangavault`
- Version 1.0.0 (build 1)
- iOS / iPadOS 17.0+, Xcode 16+
- Team: EU3UY476T6 (automatic signing)

## Open & run

1. Unzip and open `MangaVault.xcodeproj`.
2. Pick an iPhone simulator or your device and press **Run**.

No packages or extra setup — everything uses Apple frameworks (SwiftUI, Charts, PhotosUI, AuthenticationServices).

## Features (1:1 with the web app)

| Screen | What it does |
|---|---|
| Login / Register / Reset | Email + password, 6-digit email verification, password reset, Google sign-in |
| Dashboard | Level, XP, streak, 8 stat cards, status / genre / growth / rating charts, continue reading, recently added |
| Catalog | Full MangaDex catalog, search, publisher filters, Shonen Jump first, infinite scroll |
| Discover | Same catalog with OWNED badges, genre line and *Surprise me* |
| Manga detail | All volumes with covers, add/remove per volume, wishlist heart, omnibus (3-in-1) support |
| Volume detail | AI synopsis, recap, location & setting, chapters included, main characters, status, prev/next |
| Collection | Stats, search, status + favourite filters, sort, grid/list, rating, status, chapter progress, notes, remove |
| Wishlist | Total value, *Bought* moves to collection, remove |
| Statistics | 7/30/90 days / all-time activity, growth, status and genre distribution |
| Achievements | 12 achievements with rarity, progress and XP rewards (confetti on unlock) |
| Daily Quests | 4 daily quests, claim XP, resets at local midnight |
| Manga Wrapped | Year/month recap card, share as image |
| Profile | Display name, bio, avatar & banner upload, public profile / collection, share link |

XP, levels, achievements, quests and streaks use exactly the same formulas as the web app.

## Structure

```
MangaVault/
  App/        App entry, AppState (session, toasts, confetti), tabs & routing
  Core/       Base44 API client, Keychain, shared domain logic
  Models/     Entity models (Manga, CollectionItem, WishlistItem, ReadingActivity, UserProfile) and gamification
  Views/      Auth, Catalog, Collection, Stats, Profile, shared components
  Resources/  Asset catalog (app icon, accent colour)
```

## Notes

- **Google sign-in** opens the Base44 Google flow in a secure browser sheet and returns to the app via `mangavault://auth`. If Base44 refuses a custom-scheme return URL, use email + password (same account).
- Deep link to a public profile: `mangavault://u/<profileId>`.
